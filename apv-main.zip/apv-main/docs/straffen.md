# **Strafcategorieën:**

  - **Categorie 1** – Waarschuwing + 100 taakstraffen<br>
     ➥ 3 waarschuwingen in 1 maand is straf van categorie 2
  - **Categorie 2** – Ban van 1 dag
  - **Categorie 3** – Ban van 2 dagen
  - **Categorie 4** – Ban van 3 dagen
  - **Categorie 5** – Ban van 1 week
  - **Categorie 6** – Ban van 2 weken
  - **Categorie 7** – Ban van 1 maand
  - **Categorie 8** – Account-wipe (account wordt helemaal gereset)
  - **Categorie 9** – Permanente ban (Niet meer welkom)
